
export enum Category {
  SUITS = 'Suits',
  CASUAL = 'Casual',
  OUTERWEAR = 'Outerwear',
  ACCESSORIES = 'Accessories',
  FOOTWEAR = 'Footwear'
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  description: string;
  image: string;
  colors: string[];
  sizes: string[];
}

export interface CartItem extends Product {
  quantity: number;
}
