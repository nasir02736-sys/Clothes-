
import { Category, Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Italian Wool Charcoal Suit',
    price: 899,
    category: Category.SUITS,
    description: 'Masterfully crafted from premium Italian wool, this charcoal suit offers a sharp silhouette for the modern professional.',
    image: 'https://images.unsplash.com/photo-1594932224828-b4b059b6f6ee?auto=format&fit=crop&q=80&w=800',
    colors: ['Charcoal', 'Navy'],
    sizes: ['40R', '42R', '44R']
  },
  {
    id: '2',
    name: 'Cashmere Blend Crewneck',
    price: 185,
    category: Category.CASUAL,
    description: 'Unparalleled softness meets everyday luxury. A staple for layered autumn looks.',
    image: 'https://images.unsplash.com/photo-1614676466623-f8d20b512ee6?auto=format&fit=crop&q=80&w=800',
    colors: ['Beige', 'Black', 'Grey'],
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: '3',
    name: 'Technical Field Jacket',
    price: 320,
    category: Category.OUTERWEAR,
    description: 'Weather-resistant and refined. The perfect companion for transitional seasons.',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800',
    colors: ['Olive', 'Navy'],
    sizes: ['M', 'L', 'XL']
  },
  {
    id: '4',
    name: 'Hand-Burnished Oxford Shoes',
    price: 245,
    category: Category.FOOTWEAR,
    description: 'Classic elegance carved from full-grain leather with a durable Goodyear welt.',
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&q=80&w=800',
    colors: ['Cognac', 'Espresso'],
    sizes: ['9', '10', '11', '12']
  },
  {
    id: '5',
    name: 'Structured Cotton Chinos',
    price: 110,
    category: Category.CASUAL,
    description: 'Tapered fit chinos that bridge the gap between office wear and weekend relaxation.',
    image: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&q=80&w=800',
    colors: ['Khaki', 'Navy', 'Stone'],
    sizes: ['30', '32', '34', '36']
  },
  {
    id: '6',
    name: 'Silk Blend Patterned Tie',
    price: 65,
    category: Category.ACCESSORIES,
    description: 'A touch of personality for your formal attire, featuring a subtle geometric weave.',
    image: 'https://images.unsplash.com/photo-1598033129183-c4f50c7176c8?auto=format&fit=crop&q=80&w=800',
    colors: ['Blue/Silver', 'Wine'],
    sizes: ['One Size']
  }
];
