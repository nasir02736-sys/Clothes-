
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function getFashionAdvice(query: string, availableCategories: string[]) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User is asking for fashion advice: "${query}". 
      As a high-end personal stylist for RealMensClothing (men's fashion only), provide a concise, stylish recommendation. 
      Recommend specific items based on these categories: ${availableCategories.join(', ')}. 
      Keep it professional, encouraging, and sophisticated. Use about 100 words.`,
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm sorry, I'm currently refining my style guides. Please try again in a moment.";
  }
}
