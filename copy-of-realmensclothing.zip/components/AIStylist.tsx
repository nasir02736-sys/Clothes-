
import React, { useState } from 'react';
import { getFashionAdvice } from '../services/geminiService';
import { Category } from '../types';

const AIStylist: React.FC = () => {
  const [query, setQuery] = useState('');
  const [advice, setAdvice] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    const result = await getFashionAdvice(query, Object.values(Category));
    setAdvice(result || "Error getting advice.");
    setLoading(false);
  };

  return (
    <div id="stylist" className="bg-stone-50 py-20 px-4">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden flex flex-col md:flex-row">
        <div className="md:w-1/3 bg-black p-8 text-white flex flex-col justify-center">
          <h2 className="text-3xl font-bold serif mb-4">AI Personal Stylist</h2>
          <p className="text-stone-400 text-sm leading-relaxed">
            Not sure what to wear for that interview or summer wedding? Ask our AI stylist for expert advice tailored to the RealMensClothing collection.
          </p>
        </div>
        <div className="md:w-2/3 p-8">
          <form onSubmit={handleSubmit} className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">What is the occasion?</label>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full border-gray-200 border rounded-md p-4 text-gray-900 focus:ring-2 focus:ring-black outline-none transition"
              rows={3}
              placeholder="e.g., I'm attending a business formal charity gala in November. What should I wear?"
            />
            <button
              type="submit"
              disabled={loading}
              className="mt-4 w-full bg-black text-white py-3 rounded-md font-medium hover:bg-gray-800 transition disabled:bg-gray-400"
            >
              {loading ? 'CONSULTING STYLIST...' : 'GET RECOMMENDATION'}
            </button>
          </form>

          {advice && (
            <div className="bg-stone-100 p-6 rounded-md animate-fade-in">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Stylist Advice</h3>
              <p className="text-gray-800 leading-relaxed italic">"{advice}"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIStylist;
