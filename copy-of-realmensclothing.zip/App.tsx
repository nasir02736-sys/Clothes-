
import React, { useState } from 'react';
import { Product, Category, CartItem } from './types';
import { PRODUCTS } from './constants';
import Navbar from './components/Navbar';
import CartSidebar from './components/CartSidebar';
import AIStylist from './components/AIStylist';

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const filteredProducts = activeCategory === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen">
      <Navbar onOpenCart={() => setIsCartOpen(true)} cartCount={cart.reduce((s, i) => s + i.quantity, 0)} />
      
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?auto=format&fit=crop&q=80&w=2000" 
            alt="Hero Background"
            className="w-full h-full object-cover grayscale-[0.2]"
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        
        <div className="relative z-10 text-center text-white px-4">
          <h2 className="text-sm font-bold tracking-[0.5em] uppercase mb-4 animate-fade-in-up">The Modern Man's Wardrobe</h2>
          <h1 className="text-5xl md:text-7xl font-bold serif mb-8 max-w-3xl mx-auto">Elevated Essentials for the Discerning.</h1>
          <a href="#shop" className="inline-block bg-white text-black px-10 py-4 font-semibold tracking-wider hover:bg-stone-100 transition">
            DISCOVER THE COLLECTION
          </a>
        </div>
      </section>

      {/* Product Section */}
      <section id="shop" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <h3 className="text-3xl font-bold serif mb-2">Curated Selection</h3>
            <p className="text-gray-500">Quality over quantity, always.</p>
          </div>
          
          <div className="flex flex-wrap gap-4 text-sm font-medium">
            <button 
              onClick={() => setActiveCategory('All')}
              className={`pb-1 border-b-2 transition ${activeCategory === 'All' ? 'border-black text-black' : 'border-transparent text-gray-400 hover:text-black'}`}
            >
              All
            </button>
            {Object.values(Category).map(cat => (
              <button 
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`pb-1 border-b-2 transition ${activeCategory === cat ? 'border-black text-black' : 'border-transparent text-gray-400 hover:text-black'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
          {filteredProducts.map(product => (
            <div key={product.id} className="group cursor-pointer">
              <div className="relative overflow-hidden aspect-[3/4] mb-4 bg-gray-100">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <button 
                  onClick={() => addToCart(product)}
                  className="absolute bottom-0 left-0 right-0 bg-white/95 py-4 text-center font-bold text-sm tracking-widest translate-y-full group-hover:translate-y-0 transition-transform duration-300"
                >
                  QUICK ADD TO BAG
                </button>
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">{product.category}</p>
                  <h4 className="font-semibold text-gray-900 group-hover:text-gray-600 transition">{product.name}</h4>
                </div>
                <p className="font-medium text-gray-900">${product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI Stylist Section */}
      <AIStylist />

      {/* Footer */}
      <footer id="about" className="bg-white border-t border-gray-100 pt-20 pb-10 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold serif mb-6">REALMENS<span className="text-gray-400">CLOTHING</span></h2>
              <p className="text-gray-500 max-w-sm leading-relaxed mb-8">
                Founded on the principles of timeless design and impeccable craftsmanship. We provide the modern gentleman with a modular wardrobe that moves from boardroom to bistro with effortless grace.
              </p>
              <div className="flex space-x-6">
                <a href="#" className="text-gray-400 hover:text-black transition">INSTAGRAM</a>
                <a href="#" className="text-gray-400 hover:text-black transition">TWITTER</a>
                <a href="#" className="text-gray-400 hover:text-black transition">PINTEREST</a>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-sm mb-6 uppercase tracking-widest">Support</h4>
              <ul className="space-y-4 text-sm text-gray-500">
                <li><a href="#" className="hover:text-black transition">Shipping Policy</a></li>
                <li><a href="#" className="hover:text-black transition">Return & Exchange</a></li>
                <li><a href="#" className="hover:text-black transition">Size Guide</a></li>
                <li><a href="#" className="hover:text-black transition">Contact Us</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-sm mb-6 uppercase tracking-widest">Newsletter</h4>
              <p className="text-sm text-gray-500 mb-4">Join our inner circle for exclusive updates and styling guides.</p>
              <form className="flex">
                <input 
                  type="email" 
                  placeholder="Email address" 
                  className="flex-1 border border-gray-200 px-4 py-2 text-sm outline-none focus:ring-1 focus:ring-black"
                />
                <button className="bg-black text-white px-4 py-2 text-sm font-medium">JOIN</button>
              </form>
            </div>
          </div>
          <div className="border-t border-gray-100 pt-10 text-center text-xs text-gray-400 tracking-widest">
            &copy; 2024 REALMENSCLOTHING CO. ALL RIGHTS RESERVED.
          </div>
        </div>
      </footer>

      <CartSidebar 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cart} 
        onRemove={removeFromCart}
      />
    </div>
  );
};

export default App;
